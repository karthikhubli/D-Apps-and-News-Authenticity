1. The application is developed in Python 3.6.5 
2. The librarires to be installed are mentioned in /7030722s2018/source code/NewsAnalysis/requirements.txt.
3. The dataset used for training are not submitted along with other items due to the large file size. However, the are checked in the GitHub repository mentioned below.
4. To test the application on local host execute the below command 'python predictNewsAuthenticity.py' in the command prompt. Open the browser and in the url type "localhost:<port>". Port number can be obtained from command prompt after the command is executed.



Repository: https://github.com/karthikhubli/NewsAnalysis

The submission contains the following
1. Two research papers [Predicting authenticity of news article using NLP and Machine Learning][Using Blockchain technology to construct a Decentralized Application]
2. Project Report
3. Project Manual
4. Source Code